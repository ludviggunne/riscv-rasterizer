/* By: Ludvig Gunne Lindström */
#include <switch_io.h>

unsigned switch_get_all(void)
{
	return SWITCH_DATA;
}
