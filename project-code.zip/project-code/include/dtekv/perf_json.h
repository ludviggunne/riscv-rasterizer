/* By: Ludvig Gunne Lindström */
#ifndef PERF_JSON_H
#define PERF_JSON_H

/*
 * Prints profiling data as JSON to be collected by collect_profiling_data.py.
 */
void print_all_profile_windows_json(void);

#endif
