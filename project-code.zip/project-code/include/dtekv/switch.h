/* By: Ludvig Gunne Lindström */
#ifndef SWITCH_H
#define SWITCH_H

unsigned switch_get_all(void);

#endif
