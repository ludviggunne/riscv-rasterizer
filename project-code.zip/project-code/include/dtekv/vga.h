/* By: Ludvig Gunne Lindström */
#ifndef VGA_H
#define VGA_H

void *	vga_get_buf(void);
void *	vga_swap(void);
void	vga_finish(void);

#endif
