/* By: Ludvig Gunne Lindström */
#ifndef STDLIB_H
#define STDLIB_H

void abort(void);

#endif
