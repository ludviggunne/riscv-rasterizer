/* By: Ludvig Gunne Lindström */
#ifndef TIMER_H
#define TIMER_H

/* Functions for dealing with timer */

void timer_start(unsigned int ms, int cont, void (*fn)(void));

#endif
