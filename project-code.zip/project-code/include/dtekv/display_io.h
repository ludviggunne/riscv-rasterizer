/* By: Ludvig Gunne Lindström */
#ifndef DISPLAY_IO_H
#define DISPLAY_IO_H

extern volatile unsigned	DISPLAY_BASE[];

#endif
