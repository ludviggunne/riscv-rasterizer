/* By: Ludvig Gunne Lindström */
#ifndef UART_IO_H
#define UART_IO_H

extern volatile unsigned	UART_DATA;
extern volatile unsigned	UART_CONTROL;

#endif
